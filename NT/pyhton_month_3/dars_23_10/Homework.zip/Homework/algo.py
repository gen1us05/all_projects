# algo 147

# n = input()
# a = 0
# y = 0
# for i in n:
#     if i == "A":
#         a += 1
#     elif i == "Y":
#         y += 1
# print(a)
# print(y)


# algo 148

