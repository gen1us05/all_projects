myset = {"olma", "anor", 12, 34, 45, True, False}
mycars = {"matiz", "damas", "cabalt", "nexia", "olma"}

newset = myset.intersection(mycars)

print(newset)
