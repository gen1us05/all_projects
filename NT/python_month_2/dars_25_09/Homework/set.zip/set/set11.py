mytuple = ("anor", "behi", "olma", "nok")

mylist = list(mytuple)


mylist.sort(reverse=True)

mytuple = tuple(mylist)

print(mytuple)
