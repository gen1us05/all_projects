mylist = [(), (), ('',), ('a', 'b'), ('a', 'b', 'c'), ('d',)]

for i in mylist:
    d = len(i)
    if d == 0:
        mylist.remove(i)

print(mylist)
