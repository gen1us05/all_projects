
myset = {"olma", "anor", 12, 34, 45, True, False}

print(len(myset))

