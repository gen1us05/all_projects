son1 = {13, 12, 34, 45, 23, 44}
son2 = {32, 56, 76, 312, 12, 44}

newset = son1.intersection(son2)

d = min(newset)

print(d)
