myset = {"olma", "anor", 12, 34, 45, True, False}

myset.remove("olma")

print(myset)