def PowA3(a, b, c, d, e):
    a = a ** 3
    b = b ** 3
    c = c ** 3
    d = int(d ** 3)
    e = int(e ** 3)
    print(a, b, c, d, e)


PowA3(1.2, 2.1, 3.3, 2.2, 3.3)





#  ???
# def PowA3(sonlar):
#     javob = {}
#     while sonlar:
#         son = sonlar.pop()
#         kub = son ** 3
#         javob[son] = kub
#     return javob
#     print(javob)
#
#
# PowA3(12, 231, 12, 423)
