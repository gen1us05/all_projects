def PowerA234(a, b, c):
    a2 = a ** 2
    a3 = a ** 3
    a4 = a ** 4
    b2 = b ** 2
    b3 = b ** 3
    b4 = b ** 4
    c2 = c ** 2
    c3 = c ** 3
    c4 = c ** 4
    print(f" 2-daraja{a2, b2, c2}")
    print(f" 3-daraja{a3, b3, c3}")
    print(f" 4-daraja{a4, b4, c4}")


PowerA234(23, 12, 4)
