a, b, c = map(int, input().split())

d = a + b == 0 or b + c == 0 or a + c == 0

print(d)
