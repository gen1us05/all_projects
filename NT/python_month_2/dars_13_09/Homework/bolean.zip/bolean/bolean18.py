a, b, c = map(int, input().split())

d = a == b or b == c or a == c

print(d)
