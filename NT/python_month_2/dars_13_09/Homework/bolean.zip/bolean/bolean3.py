a = int(input("son kiriting:"))

b = a % 2 == 0

print(b)
