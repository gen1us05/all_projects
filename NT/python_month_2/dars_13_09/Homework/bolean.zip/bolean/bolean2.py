a = int(input("son kiriting:"))

b = a % 2 == 1

print(b)
