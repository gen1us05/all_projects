a = int(input("son kiriting: "))

b = a > 9 and a < 100 and a % 2 == 0

print(b)
