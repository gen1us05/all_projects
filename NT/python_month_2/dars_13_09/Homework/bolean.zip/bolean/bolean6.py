a = int(input("birinchi sonni kiriting:"))
b = int(input("ikkinchi sonni kiriting:"))
c = int(input("uchinchi sonni kiriting:"))

d = a <= b and b <= c

print(d)
