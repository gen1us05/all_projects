
a = int(input("son kiriting:"))

b = a>=0

print(b)
