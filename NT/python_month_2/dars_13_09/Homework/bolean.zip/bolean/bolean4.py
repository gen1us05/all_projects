a = int(input("birinchi sonni kiriting:"))
b = int(input("ikkinchi sonni kiriting:"))

c = a > 2 and b <= 3

print(c)
