a = int(input("son kiriting: "))

b = a > 99 and a < 1000 and a % 2 == 1

print(b)
