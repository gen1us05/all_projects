a = int(input("birinchi sonni kiriting:"))
b = int(input("ikkinchi sonni kiriting:"))

c = a % 2 == 1 or b % 2 == 1

print(c)
